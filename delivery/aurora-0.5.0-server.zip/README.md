# 曜集 0.5.0 · 预构建测试服务包

本包不需要 HBuilderX、Vite、Vue 编译器或 Python。需要 Node.js 24+ 和 npm。

Windows：解压全部文件后双击 `START-WINDOWS.cmd`，自动进入正确目录、检查环境并安装缺失依赖。
启动器不会修改已有 `.env` 或 `.data`；出错会暂停显示原因。

也可在解压目录使用 PowerShell：

```powershell
npm.cmd ci --omit=dev
npm.cmd start
```

Linux / 宝塔：

```bash
npm ci --omit=dev
npm start
```

默认仅监听本机 3001，首页和 API 同端口。打开该电脑浏览器访问 http://127.0.0.1:3001/ 。
宝塔公开访问必须按 docs/BAOTA.md 设置 HTTPS 和访问范围限制，禁止把源码根目录设为网站根目录。

首次启动会创建 .env 并生成随机后台 ADMIN_TOKEN，不会打印凭证或覆盖旧配置。
后台入口在网站页脚及个人中心；请在本机安全查看 .env 使用运营凭证，不要公开或发送给他人。
检查环境：npm run doctor。数据库一致性备份：npm run backup。
恢复到全新独立文件：参见 docs/RESTORE.md；不会自动切换运行数据。
升级前备份并保留自己的 .env、.data；不要复制旧 node_modules 或覆盖生产数据。

已包含账号密码注册/登录/改密、商品库存、订单、商家发货记录、售后审核、积分规则与兑换处理记录。
匿名体验与注册账号不自动合并；没有密码找回功能，请妥善保管账号和密码。
仍为测试环境：不真实收款、退款、发货或展示广告；不代表完成四端真机与平台审核。
业务数据与个人信息保护仍不满足生产门槛。商品图片为示意图，非品牌授权证明。
